#ifndef __CORRESPOND_H
#define __CORRESPOND_H
/* 电机控制User用户设置·通信协议设定 */
#include "Sguan_UART.h"

/* ================= 驱动代码(驱动层) ================= */
static inline void User_CorrespondSet(unsigned char *ch, unsigned short int size){
    /* Your code for UART or CAN Signal Transmit Driver */
    // like: HAL_UART_Transmit(&huart1, ch, size, 0xFFFF);
    /* 使用UART6发送数据（堵塞方式） */
    // unsigned char *buf = ch;
    // unsigned short int i;
    
    // for(i = 0; i < size; i++) {
    //     while(USART_GetFlagStatus(UART6, USART_FLAG_TXE) == RESET);
    //     USART_SendData(UART6, *buf++);
    // }
    // Sguan_UART_SendData(ch,size);
}


#endif // CORRESPOND_H
