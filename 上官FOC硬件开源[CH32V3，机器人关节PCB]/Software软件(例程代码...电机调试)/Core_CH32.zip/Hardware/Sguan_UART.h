#ifndef __SGUAN_UART_H
#define __SGUAN_UART_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ch32v30x.h"

/* �������� */
void Sguan_UART_Init(void);
void Sguan_UART_SendByte(uint8_t data);
void Sguan_UART_SendString(char *str);
void Sguan_UART_SendData(uint8_t *data, uint16_t len);
uint8_t* Sguan_UART_GetRxBuffer(void);
uint16_t Sguan_UART_GetRxCount(void);
void Sguan_UART_ClearRxCount(void);

#ifdef __cplusplus
}
#endif

#endif /* __SGUAN_UART_H */
