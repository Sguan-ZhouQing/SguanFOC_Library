/********************************** (C) COPYRIGHT *******************************
* File Name          : Sguan_UART.c
* Author             : Sguan
* Version            : V1.0.0
* Date               : 2026/04/19
* Description        : UART driver source file (UART6_TX + USART1_RX)
********************************************************************************/
#include "Sguan_UART.h"
#include "SguanFOC.h"
#include <string.h>

/* 私有变量 */
static volatile uint16_t RxCount = 0;

/*********************************************************************
 * @fn      Sguan_UART_Init
 *
 * @brief   初始化UART6_TX (PB8) 和 USART1_RX (PB7)
 *          波特率1M，8位数据，1位停止位，无校验
 *          
 *          UART6_TX: PB8 (重映射 USART6_TX_1)
 *          USART1_RX: PB7 (重映射 USART1_RX_1)
 *
 * @return  none
 *********************************************************************/
void Sguan_UART_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    USART_InitTypeDef USART_InitStructure = {0};
    // NVIC_InitTypeDef NVIC_InitStructure = {0};
    
    /* 使能时钟 */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART6, ENABLE);
    
    /* ========== 配置 UART6_TX (PB8) ========== */
    /* 重映射UART6到PB8 (使用部分重映射或完全重映射) */
    GPIO_PinRemapConfig(GPIO_PartialRemap_USART6, ENABLE);
    
    /* 配置PB8为复用推挽输出 */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    /* 配置UART6 */
    USART_InitStructure.USART_BaudRate = 1000000;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx;  // 只发送
    USART_Init(UART6, &USART_InitStructure);
    
    /* 使能UART6 */
    USART_Cmd(UART6, ENABLE);
    
    // /* ========== 配置 USART1_RX (PB7) ========== */
    // /* 重映射USART1_RX到PB7 */
    // GPIO_PinRemapConfig(GPIO_Remap_USART1, ENABLE);
    
    // /* 配置PB7为浮空输入 */
    // GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
    // GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    // GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    // /* 重新初始化USART1结构体 */
    // USART_InitStructure.USART_BaudRate = 1000000;
    // USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    // USART_InitStructure.USART_StopBits = USART_StopBits_1;
    // USART_InitStructure.USART_Parity = USART_Parity_No;
    // USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    // USART_InitStructure.USART_Mode = USART_Mode_Rx;  // 只接收
    // USART_Init(USART1, &USART_InitStructure);
    
    // /* 配置接收完成中断 (RXNE) */
    // USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    
    // /* 配置NVIC中断优先级 */
    // NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    // NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    // NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    // NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    // NVIC_Init(&NVIC_InitStructure);
    
    // /* 使能USART1 */
    // USART_Cmd(USART1, ENABLE);
}

/*********************************************************************
 * @fn      Sguan_UART_SendByte
 *
 * @brief   通过UART6发送一个字节
 *
 * @param   data - 要发送的数据
 *
 * @return  none
 *********************************************************************/
void Sguan_UART_SendByte(uint8_t data)
{
    /* 等待发送缓冲区空 */
    while(USART_GetFlagStatus(UART6, USART_FLAG_TXE) == RESET);
    
    /* 发送数据 */
    USART_SendData(UART6, data);
}

/*********************************************************************
 * @fn      Sguan_UART_SendString
 *
 * @brief   发送字符串
 *
 * @param   str - 要发送的字符串（以'\0'结尾）
 *
 * @return  none
 *********************************************************************/
void Sguan_UART_SendString(char *str)
{
    while(*str != '\0')
    {
        Sguan_UART_SendByte((uint8_t)(*str++));
    }
}

/*********************************************************************
 * @fn      Sguan_UART_SendData
 *
 * @brief   发送指定长度的数据
 *
 * @param   data - 数据缓冲区指针
 * @param   len - 要发送的数据长度
 *
 * @return  none
 *********************************************************************/
void Sguan_UART_SendData(uint8_t *data, uint16_t len)
{
    uint16_t i;
    
    for(i = 0; i < len; i++)
    {
        Sguan_UART_SendByte(data[i]);
    }
}

/*********************************************************************
 * @fn      Sguan_UART_GetRxBuffer
 *
 * @brief   获取接收缓冲区指针
 *
 * @return  接收缓冲区指针
 *********************************************************************/
uint8_t* Sguan_UART_GetRxBuffer(void)
{
    return Sguan_PrintfBuff;
}

/*********************************************************************
 * @fn      Sguan_UART_GetRxCount
 *
 * @brief   获取已接收数据长度
 *
 * @return  已接收数据长度
 *********************************************************************/
uint16_t Sguan_UART_GetRxCount(void)
{
    return RxCount;
}

/*********************************************************************
 * @fn      Sguan_UART_ClearRxCount
 *
 * @brief   清除接收计数
 *
 * @return  none
 *********************************************************************/
void Sguan_UART_ClearRxCount(void)
{
    RxCount = 0;
}

/*********************************************************************
 * @fn      USART1_IRQHandler
 *
 * @brief   USART1中断处理函数（接收中断）
 *          接收数据并存入缓冲区，当收到'?'时调用解析函数
 *
 * @return  none
 *********************************************************************/
void USART1_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void USART1_IRQHandler(void)
{
    uint8_t data;

    /* 检查接收中断标志 */
    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        /* 读取接收到的数据 */
        data = USART_ReceiveData(USART1);
 
        /* 如果缓冲区未满，存入缓冲区 */
        if(RxCount < 200 - 1)
        {
            Sguan_PrintfBuff[RxCount++] = data;
            
            if(data == '?')
            {
                /* 调用FOC解析函数 */
                // SguanFOC_Printf_Loop(Sguan_PrintfBuff, RxCount);
    
                /* 清除缓冲区 */
                RxCount = 0;
            }
        }
        else
        {
            /* 缓冲区满，丢弃数据并重置 */
            RxCount = 0;
        }
    }
}
