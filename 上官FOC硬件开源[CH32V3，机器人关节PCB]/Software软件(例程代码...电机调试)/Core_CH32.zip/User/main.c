/********************************** (C) COPYRIGHT *******************************
* File Name          : main.c
* Author             : WCH
* Version            : V1.0.0
* Date               : 2021/06/06
* Description        : Main program body.
*********************************************************************************
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* Attention: This software (modified or not) and binary are used for 
* microcontroller manufactured by Nanjing Qinheng Microelectronics.
*******************************************************************************/

/*
 *@Note
 USART Print debugging routine:
 USART1_Tx(PA9).
 This example demonstrates using USART1(PA9) as a print debug port output.

*/

#include "debug.h"


/* Global typedef */
#include "Sguan_ADC.h"
#include "Sguan_TIM.h"
#include "Sguan_UART.h"
#include "Sguan_GPIO.h"
#include "KTH7823_Driver.h"
#include "Key.h"

#include "SguanFOC.h"
/* Global define */

/* Global Variable */


/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
int main(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	SystemCoreClockUpdate();
	Delay_Init();

	Delay_Ms(1000);
    // Sguan_*ϵ�������ʼ��
    // Sguan_UART_Init();
    // Sguan_ADC_Init();
    Sguan_TIM_Init();
    Sguan_GPIO_Init();
    KTH7823_SPI_Init();
	Sguan.status = 0x01;
	while(1)
    {
		// uint8_t num = Key_GetNum();
		// // uint8_t num = 1;
		// if (num == 1) {
		// 	GPIO_ResetBits(GPIOA, GPIO_Pin_12);
		// }
		// if (num == 2) {
		// 	GPIO_SetBits(GPIOA, GPIO_Pin_12);
		// }
		// GPIO_WriteBit(GPIOA, GPIO_Pin_12, 
		// 		(BitAction)(1));
		// 		// (BitAction)(1 - GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_12)));
		// Delay_Ms(180);
        SguanFOC_main_Loop();
	}
}

